#include "ros/ros.h"
#include "ros/time.h"

#include "std_msgs/Float64.h"

//  global parameters


ros::Publisher j0_pub_;
ros::Publisher j1_pub_;
ros::Publisher j2_pub_;
ros::Publisher j3_pub_;
ros::Publisher j4_pub_;
ros::Publisher j5_pub_;
ros::Publisher j6_pub_;

const int max_effort = 176;

void send_effort_commands()
{
	std_msgs::Float64 eff_cmd;

	ROS_INFO("Calculating joint angles");

	ros::Time time_now = ros::Time::now();

	eff_cmd.data = max_effort*cos(1*time_now.sec);
	j0_pub_.publish(eff_cmd);

	eff_cmd.data = max_effort*sin(1*time_now.sec);
	j1_pub_.publish(eff_cmd);

	eff_cmd.data = max_effort*cos(1*time_now.sec);
	j2_pub_.publish(eff_cmd);

	eff_cmd.data = max_effort*cos(1*time_now.sec);
	j3_pub_.publish(eff_cmd);

	eff_cmd.data = max_effort*cos(1*time_now.sec);
	j4_pub_.publish(eff_cmd);

	eff_cmd.data = max_effort*cos(1*time_now.sec);
	j5_pub_.publish(eff_cmd);

	eff_cmd.data = max_effort*cos(1*time_now.sec);
	j6_pub_.publish(eff_cmd);

	// wait 0.01 seconds -> 100Hz
	ros::Duration(0.01).sleep();

}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "move_arm");
	ros::NodeHandle n;

	j0_pub_  = n.advertise<std_msgs::Float64>("/kuka/joint0_effort_controller/command", 100);
	j1_pub_  = n.advertise<std_msgs::Float64>("/kuka/joint1_effort_controller/command", 100);
	j2_pub_  = n.advertise<std_msgs::Float64>("/kuka/joint2_effort_controller/command", 100);
	j3_pub_  = n.advertise<std_msgs::Float64>("/kuka/joint3_effort_controller/command", 100);
	j4_pub_  = n.advertise<std_msgs::Float64>("/kuka/joint4_effort_controller/command", 100);
	j5_pub_  = n.advertise<std_msgs::Float64>("/kuka/joint5_effort_controller/command", 100);
	j6_pub_  = n.advertise<std_msgs::Float64>("/kuka/joint6_effort_controller/command", 100);

	while(ros::ok()) {
		send_effort_commands();
		ros::spinOnce();
	}




	return 0;
}
